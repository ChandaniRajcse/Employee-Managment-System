<html>
<head>
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
    <script src="js/jquery-3.5.1.min.js"></script>
    <script src="js/bootstrap.js"></script>
    <style>
        .top1 {
            display: flex;
            justify-content: center; /* Center the content */
            align-items: center; /* Vertically align the content */
            background: #e8e8ff;
            height: 50px;
        }

        .top1 .col-sm-3 {
            display: flex;
            justify-content: center; /* Center each column content */
        }

        .social .fa:hover {
            color: #ff9d0c;
            transition: all ease 1s;
        }

        #menu a {
            color: blue;
        }

        /* Align navbar items to the right */
        .navbar-nav {
            margin-left: auto; /* Push items to the right */
        }

        .cat {
            padding: 30%;
        }

        .main {
            min-height: 550px;
            background: #f1f3f4;
        }

        .contact {
            min-height: 550px;
            background: linear-gradient(45deg, #66a3d1 50%, #ff9e0e 50%);
        }

        .gallery {
            min-height: 600px;
        }

        .ufooter {
            height: 45px;
            background: #000000;
            color: white;
            text-align: center;
            padding: 10px 0;
        }

        .bfooter {
            height: 30px;
            background: black;
        }

        .cform {
            min-height: 300px;
            background: white;
        }

        .gmap {
            border: 10px solid white;
        }

        .gallery img:hover {
            transform: scale(1.1);
            transition: all ease 1s;
            filter: grayscale(100%);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .top1 {
                height: auto;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row top1 border" id="t">
            <div class="col-sm-3 border-right"><span class="fa fa-phone"></span><b>+91,9219041124</b></div>
            <div class="col-sm-3 border-right"><span class="fa fa-envelope"><b>chandaniggpa@gmail.com</b></span></div>
            <div class="col-sm-3 border-right"><b>EMPLOYEE MANAGEMENT SYSTEM</b></div>
            <div class="col-sm-3 social">
            <a href="https://www.linkedin.com/in/chandaniraj">
                <span class="fa fa-linkedin-square mr-2"></span>
            </a>
            <a href="https://www.github.com/ChandaniRajcse">
                <span class="fa fa-github-square mr-2"></span>
    </a>
    <a href="https://www.instagram.com/itz_jini_23/?hl=en">
                <span class="fa fa-instagram mr-2"></span>
               
    </a>
    <a href="https://youtube.com/@itz_jini_ssm23?si=AaQS38YdGb9g2fqe">
                <span class="fa fa-youtube-square mr-2"></span>
    </a>
            </div>
        </div>
        <div class="row header">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3 pt-3">
                        <img src="images/ggpalogo.jpg" height="60px" width="40%" class="img-fluid">
                    </div>
                    <div class="col-sm-9">
                        <nav class="navbar navbar-expand-lg navbar-light">
                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                                <div class="navbar-nav" id="menu">
                                    <a class="nav-link active" href="#"><span class="fa fa-home"></span><b>HOME</b><span class="sr-only">(current)</span></a>
                                    <a class="nav-link" href="#main"><b>ABOUT US</b></a>
                                    <a class="nav-link" href="registeration.php"><b>REGISTER</b></a>
                                    <a class="nav-link" href="login.php"><b>LOGIN</b></a>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <div class="row slider">
            <div class="container">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="images/ems1.png" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="images/ems6.AVIF" class="d-block w-100" alt="...">
                        </div>
                        <div class="carousel-item">
                            <img src="images/ems9.jpg" class="d-block w-100" alt="...">
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="sr-only">Next</span>
                    </a>
                </div>
            </div>
        </div>

        <div class="row main py-5" id="main">
            <div class="col-sm-12 text-center h2">ABOUT<b style="color:#66a3d1">US
                <span class="fa fa-users"></b></div>
            <div class="container text-justify"><b>
                Employee Management System is a distributed application that enables users to create and store Employee Records. This application is useful to department of the organization which maintains data of employees related to an organization. Employee Management is the modern computer based record management system of employee of any firm. Since it would be very difficult for any firm to maintain the records of employee on the papers and keep their attendance records also, we tried to convert this manpower to computer power. admin side manages all the management like editing site contents, managing employee activities.The Management System helps in management of employee database. It also deals with manipulation of the details of the employees.
                The System may also be used as a quick reference.
                In this world of growing technologies everything has been computerized.
                With large number of work opportunities the Human workforce has increased.
                Thus there is a need of a system which can handle the data of such a large number of Employees in an organization. 
                This project simplifies the task of maintain records because of its user friendly nature.<b>
            </div>
        </div>

        <a class="nav-link" href="#t"><input type="submit" value="TOP" class="btn btn-primary"></a>

        <div class="row ufooter" id="l">
            <div class="col-sm-12">2020 EMS | All Rights REserved |</div>
            <div class="col-sm-12">Chandani Raj |Privacy Policy|</div>
        </div>
        <div class="row bfooter"></div>
    </div>
</body>
</html>
