-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2024 at 05:57 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ems`
--

-- --------------------------------------------------------

--
-- Table structure for table `applied_leave`
--

CREATE TABLE `applied_leave` (
  `id` int(100) NOT NULL,
  `1_from` date DEFAULT NULL,
  `1_to` date DEFAULT NULL,
  `e_leave` varchar(250) DEFAULT NULL,
  `m_leave` varchar(250) DEFAULT NULL,
  `c_leave` varchar(250) DEFAULT NULL,
  `apply_by` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assign_leave`
--

CREATE TABLE `assign_leave` (
  `id` int(100) NOT NULL,
  `v_from` date DEFAULT NULL,
  `v_to` date DEFAULT NULL,
  `e_leave` varchar(250) DEFAULT NULL,
  `m_leave` varchar(250) DEFAULT NULL,
  `c_leave` varchar(250) DEFAULT NULL,
  `assign_to` varchar(250) DEFAULT NULL,
  `assign_by` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assign_leave`
--

INSERT INTO `assign_leave` (`id`, `v_from`, `v_to`, `e_leave`, `m_leave`, `c_leave`, `assign_to`, `assign_by`) VALUES
(1, '2024-08-07', '2024-08-10', '5', '2', '1', '15', '13'),
(2, '2024-09-26', '2024-09-18', '9', '2', '3', '26', '25'),
(3, '2024-09-10', '2024-10-03', '5', '6', '7', '26', '25');

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

CREATE TABLE `task` (
  `t_id` int(100) NOT NULL,
  `task` varchar(250) DEFAULT NULL,
  `date_time` timestamp(6) NULL DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `assigned_by` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`t_id`, `task`, `date_time`, `user_id`, `assigned_by`) VALUES
(3, 'Define the php and Laravel knowledge', NULL, '15', ''),
(4, 'Hii please learn about html ', NULL, '15', ''),
(5, 'jhj', NULL, '24', '24'),
(6, 'jghjg', NULL, '26', '25'),
(7, 'hjgjh', NULL, '26', '25'),
(8, 'jghj', NULL, '24', '25'),
(9, 'jdhsj', NULL, '24', '25');

-- --------------------------------------------------------

--
-- Table structure for table `task_reply`
--

CREATE TABLE `task_reply` (
  `r_id` int(100) NOT NULL,
  `reply` varchar(250) DEFAULT NULL,
  `m_id` varchar(250) DEFAULT NULL,
  `reply_by` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `task_reply`
--

INSERT INTO `task_reply` (`r_id`, `reply`, `m_id`, `reply_by`) VALUES
(2, '	ok Im try to learn as soon as possible', '3', '13'),
(3, '	ok i will try to  learn as soon as posible', '4', '13'),
(4, '	cb nm ', '3', '1'),
(5, '	hii', '3', '1'),
(6, '	kj', '5', '24'),
(7, '	jhjk', '6', '25'),
(8, '	jhj', '7', '26');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(40) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `password` varchar(250) DEFAULT NULL,
  `department` varchar(250) DEFAULT NULL,
  `role` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `password`, `department`, `role`) VALUES
(24, 'chandani Raj cse', 'chandaniraj602@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Web Development', 'employee'),
(25, 'Hrishita Mishra', 'hrishitamishra218@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'SEO', 'admin'),
(26, 'chandani Raj', 'chandaniggpa@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Web Development', 'employee'),
(27, 'chandani Raj', 'chandaniggpa@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Web Development', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `applied_leave`
--
ALTER TABLE `applied_leave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assign_leave`
--
ALTER TABLE `assign_leave`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `task`
--
ALTER TABLE `task`
  ADD PRIMARY KEY (`t_id`);

--
-- Indexes for table `task_reply`
--
ALTER TABLE `task_reply`
  ADD PRIMARY KEY (`r_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `applied_leave`
--
ALTER TABLE `applied_leave`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `assign_leave`
--
ALTER TABLE `assign_leave`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `task`
--
ALTER TABLE `task`
  MODIFY `t_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `task_reply`
--
ALTER TABLE `task_reply`
  MODIFY `r_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
