<?php include "../auth/auth.php"?>
<html>
  <head>
    <title>leave</title>
	 <link href="../css/style2.css" rel="stylesheet">
	 <script src="js/jquery-3.5.1.min.js"></script>
	 <!--<link href="css/bootstrap.css" rel="stylesheet"/>-->
	 <style>
	      .a{
			  min-height:700px;
			  background:url(images/net7.png);
			  background-size:100% 100%;
			  background:;
		  }
	 </style>
	 <script>
   function checkeleave(str)
{
    var vfrm=('.e_leave').text();
    alert(vfrm);
}
 function checkDate(str)
 {
	var vfrm=$('.v_from').val();
	alert(vfrm);
 }
 </script>
	  </head>
  <body>
  <!----including header here----->
     <?php include "header.php";?>
  <!------------end header here-------------->
<h3>Leave List</h3>
<table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>Employee Name</th>
      <th>Earning Leave</th>
      <th>Medical Leave</th>
	  <th>casual Leave</th>
	  <th>valid from</th>
	  <th>valid To</th>
    </tr>
  </thead>
  <tbody>
  <?php
    $i=1;
	$user_id=$_SESSION['user_id'];
	$query="select * from `assign_leave` t1 join `users` t2 on t1.assign_to=t2.user_id where t2.user_id=
	$user_id";
	$res=mysqli_query($conn,$query);
	$count=mysqli_num_rows($res);
	if($count>0){
	while($row=mysqli_fetch_array($res))
	{
  ?>
    <tr>
	  <td><?php echo $row['name'];?></td>
	  <td class="eleave"><?php echo $row['e_leave'];?></td>
	  <td class="mleave"><?php echo $row['m_leave'];?></td>
	  <td class="cleave"><?php echo $row['c_leave'];?></td>
	  <td class="v_from"><?php echo $row['v_from'];?></td>
	  <td class="v_to"><?php echo $row['v_to'];?></td>
      </tr>
	<?php $i++;
	}}
	else{
		echo "No record Found";
	}?>
     </tbody>
</table>	  
    </div>
	<!--<?php include "footer.php";?>-->
 

 </div>
 </div>
 </body>
 </html>
