<?php
 session_start();
$host="localhost";
$username="root";
$pass="";
$db="ems";

$conn=mysqli_connect($host,$username,$pass,$db);
if(!$conn){
        die("Database connection error");
}
//insert query for register page
if(isset($_REQUEST['l_from']))
{
	 $l_from=$_POST['l_from'];
	 $l_to=$_POST['l_to'];
	 $eleave=$_POST['eleave'];
	 $mleave=$_POST['mleave'];
	 $cleave=$_POST['cleave'];
	 $apply_by=$_POST['user_id'];
    $query="INSERT INTO `applied_leave`(`id`,`l_from`,`l_to`,`e_leave`,`m_leave`,`c_leave`,`apply_by`)
    VALUES('','$l_from','$l_to','$eleave','$mleave','$cleave','$apply_by')";
    $res=mysqli_query($conn,$query);
    if($res)
	{
	$_SESSION['success']="Leave Applied successfully";
	header('Location:leave.php');
    }
else{
	echo "Leave not applied,please try again!";
    }
} 
?>