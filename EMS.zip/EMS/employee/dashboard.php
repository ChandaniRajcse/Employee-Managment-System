<?php
error_reporting(0);
session_start();
include("../auth/auth.php");
if(isset($_SESSION['role'])&& $_SESSION['role']==='employee'&& isset($_SESSION['user_id']))
{
?>
<html>
  <head>
    <title>login</title>
	 <link href="../css/style2.css" rel="stylesheet">
	 <script src="js/jquery-3.5.1.min.js"></script>
	 <link href="css/bootstrap.css" rel="stylesheet"/>
	 <style>
	      .a{
			  min-height:700px;
			  background:url(images/net7.png);
			  background-size:100% 100%;
		  }
		  .i{
			  height:10px;
			  
		  }
		  .d{
			  height:57px;
		  }
         </style>
	  </head>
  <body>
  <!----including header here----->
  <?php include "header.php";?>
    <!------------end header here-------------->
<?php echo "<b style='color:#66a3d1'><h3>Welcome to Employee dashboard</h3>";?>
<div class="i">
</div>
<div class="img-fluid">
      <img src="../images/ems.png" style="height:100%;width:100%;"class="d-block w-100" alt="">
	  </div>
	<div class="d">  
	</div>  
<?php include "footer.php";?>

 </body>
</html>
<?php }
else{
    header('Location:../login.php');
}
?>