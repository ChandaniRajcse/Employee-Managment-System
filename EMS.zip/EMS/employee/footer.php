<html>
  <head>
     <link href="css/bootstrap.css"rel="stylesheet">
     <link href="css/font-awesome.css"rel="stylesheet">
     <script src="js/jquery-3.5.1.min.js"></script>
	 <script src="js/bootstrap.js"></script>
	 <style>
	 
	  .bfooter{
	  height:80px;
	  background:black;
	  margin:0;
	 padding:0;
	line-height:80px;
	color:white;
	text-align:center;
	font-size:15px;
	   }
	 </style>
	</head>
	<body>
	     <div class="row bfooter">
                    <span>@Copyright 2020 GGP Amethi, Developed by the Chandani Raj</span></div>
	</div>
  </body>
</html>