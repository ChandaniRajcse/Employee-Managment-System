<?php include "../auth/auth.php"?>
<html>
  <head>
    <title>login</title>
	 <link href="../css/style2.css" rel="stylesheet">
	<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

	 <!--<link href="css/bootstrap.css" rel="stylesheet"/>-->
	 <style>
	      .a{
			  min-height:700px;
			  background:url(images/net7.png);
			  background-size:100% 100%;
			  background:;
		  }
	 </style>
	  </head>
  <body>
  <!----including header here----->
     <?php include "header.php";?>
  <!------------end header here-------------->
<h3>All Task Lists</h3>
<table class="table table-striped table-hover ">
  <thead>
    <tr>
      <th>Sr No.</th>
      <th>Task</th>
      <th>Date</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
  <?php
    $i=1;
    $query="select * from task ";
	$res=mysqli_query($conn,$query);
	$count=mysqli_num_rows($res);
	if($count>0){
	while($row=mysqli_fetch_array($res))
	{
  ?>
    <tr>
      <td><?php echo $i;?></td>
      <td><a href="view-message.php?id=<?php echo $row['t_id']; ?>"><?php echo substr($row['task'],0,50);?></td>
      <td><?php echo $row['date_time']?></a></td>
      
      <td><a href="view-message.php?id=<?php echo $row['t_id']; ?>">view</a></td>
	 </tr>
	<?php $i++;}}else{
		echo "No record Found";
	}?>
     </tbody>
</table>
