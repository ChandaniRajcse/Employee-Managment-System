<?php
session_start();
$host = "localhost";
$username = "root";
$pass = "";
$db = "ems";

$conn = mysqli_connect($host, $username, $pass, $db);
if (!$conn) {
    die("Database connection error");
}

// Insert query for register page
if (isset($_POST['validfrm'])) {
    // Input sanitization (optional, but recommended)
    $validfrm = mysqli_real_escape_string($conn, $_POST['validfrm']);
    $validto = mysqli_real_escape_string($conn, $_POST['validto']);
    $eleave = mysqli_real_escape_string($conn, $_POST['eleave']);
    $mleave = mysqli_real_escape_string($conn, $_POST['mleave']);
    $cleave = mysqli_real_escape_string($conn, $_POST['cleave']);
    $assigned_by = mysqli_real_escape_string($conn, $_POST['assign_by']);

    if (isset($_POST['emp']) && is_array($_POST['emp'])) {
        $emplist = $_POST['emp'];

        $res = false; // Initialize to false
        foreach ($emplist as $emp) {
            // Prepare SQL query for each employee
            $query = "INSERT INTO `assign_leave` (`id`, `v_from`, `v_to`, `e_leave`, `m_leave`, `c_leave`, `assign_to`, `assign_by`)
                      VALUES ('', '$validfrm', '$validto', '$eleave', '$mleave', '$cleave', '$emp', '$assigned_by')";
            
            $res = mysqli_query($conn, $query);

            // Check if query failed for any employee
            if (!$res) {
                echo "Error inserting data for employee ID: $emp. " . mysqli_error($conn);
                break; // Stop further insertions if there's an error
            }
        }

        if ($res) {
            $_SESSION['success'] = "Leave Assigned successfully";
            header('Location: assign-leave.php');
            exit(); // Ensure no further execution
        } else {
            echo "Data not inserted due to an error.";
        }
    } else {
        echo "No employees selected.";
    }
}
?>
