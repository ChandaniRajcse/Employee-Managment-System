<?php include "../auth/auth.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Leaves</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style2.css" rel="stylesheet">
    <style>
        .a {
            min-height: 700px;
            background: url(images/net7.png) no-repeat center center;
            background-size: cover;
            padding: 20px;
            margin-top: 20px;
            border-radius: 10px;
        }
    </style>
</head>
<body>

    <!-- Including header here -->
    <?php include "header.php"; ?>
    <!-- End header -->

    <div class="container a">
        <h3 class="text-center">All Employee Leaves Lists</h3>

        <!-- Table becomes responsive on smaller screens -->
        <div class="table-responsive">
            <table class="table table-striped table-hover table-bordered">
                <thead class="thead-dark">
                    <tr>
                        <th>Sr No.</th>
                        <th>Employee Name</th>
                        <th>Earning Leave</th>
                        <th>Medical Leave</th>
                        <th>Casual Leave</th>
                        <th>Valid From</th>
                        <th>Valid To</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $i = 1;
                $query = "SELECT * FROM `assign_leave` t1 JOIN `users` t2 ON t1.assign_to=t2.user_id";
                $res = mysqli_query($conn, $query);
                $count = mysqli_num_rows($res);

                if ($count > 0) {
                    while ($row = mysqli_fetch_array($res)) {
                ?>
                    <tr>
                        <td><?php echo $i; ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['e_leave']); ?></td>
                        <td><?php echo htmlspecialchars($row['m_leave']); ?></td>
                        <td><?php echo htmlspecialchars($row['c_leave']); ?></td>
                        <td><?php echo htmlspecialchars($row['v_from']); ?></td>
                        <td><?php echo htmlspecialchars($row['v_to']); ?></td>
                    </tr>
                <?php
                        $i++;
                    }
                } else {
                    echo "<tr><td colspan='7' class='text-center'>No record found.</td></tr>";
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
