<html>
  <head>
     <link href="css/bootstrap.css"rel="stylesheet">
     <link href="css/font-awesome.css"rel="stylesheet">
     <script src="js/jquery-3.5.1.min.js"></script>
	 <script src="js/bootstrap.js"></script>
	 <style>
	   .top1{
	     text-align:center;
		 background:#e8e8ff;
	   }
	   .social .fa:hover
	   {
	   color:#ff9d0c;
	   transition:all ease 1s;
	   }
	  #menu a:
	   {
	   color:orange;
	   }
	   .cat
	   {
	    padding:30%;
	   }
	   .main{
	   min-height:550px;
	   background:#f1f3f4;
	   }
	   .contact{
	   min-height:550px;
	   background:linear-gradient(45deg,#66a3d1 50%,#ff9e0e 50%);
	   }
	   .gallery{
	    min-height:600px;
	   }
	   .ufooter{
	    height:45px;
	   background:#000000;
	  }
	  .bfooter{
	  height:45px;
	  background:black;
	   }
	   .cform{
	     min-height:300px;
		 background:white;
	   }
	   .gmap{
	   border:10px solid white;
	   }
	   .gallery img:hover{
	   transform:scale(1.1);
	   transition:all ease 1s;
	   filter:grayscale(100%);
	   }
	 </style>
  </head>
  <body>
    <div class="container-fluid">
	 <div class="row top1 border" id="t">
	    <div class="col-sm-3 border-right"><span class="fa 
		fa-phone"></span>+91,9219041124</div>
	    <div class="col-sm-3 border-right">
		<span class="fa fa-envelope">chandaniggpa@gmail.com</span>
		</div>
	    <div class="col-sm-3 border-right">
	     GOVT GIRLS POLYTECHNIC AMETHI
		</div>
	    <div class="col-sm-3 social">
		<span class="fa fa-facebook-square mr-2"></span>
		<span class="fa fa-twitter-square mr-2"></span>
		<span class="fa fa-instagram mr-2"></span>
		<span class="fa fa-youtube-square mr-2"></span>
		</div>
	 </div>
     <div class="row header">
	 <div class="container">
	 <div class="row">
	 <div class="col-sm-3 pt-3">
	 <img src="images/ggpalogo.jpg"height="60px" width="40%"class="img-fluid">
	 </div>
     <div class="col-sm-9">
	 <nav class="navbar navbar-expand-lg navbar-light float-right">
     <button class="navbar-toggler" type="button" 
	 data-toggle="collapse" data-target="#navbarNavAltMarkup" 
	 aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
     <span class="navbar-toggler-icon"></span>
     </button>
     <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
     <div class="navbar-nav" id="menu">
     <a class="nav-link active" href="#"><span class="fa 
	 fa-home"></span><b>HOME</b><span class="sr-only">(current)</span></a>
     <a class="nav-link" href="#main"><b>ABOUT US</b></a>
     <a class="nav-link" href="registeration.php"><b>REGISTER</b></a>
     <a class="nav-link" href="login.php"><b>LOGIN</b></a>
    </div>
  </div>
</nav>
	 </div>
     </div>
	 </div>
	 </div>
     <div class="row slider">
	 <div class="container">
	 <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/Ems.png" style="border:10px solid black"class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="images/Ems8.jpg" style="border:10px solid black"class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="images/Ems12.png" style="border:10px solid black" class="d-block w-100" alt="...">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>
	 </div>
     <div class="row category">
	 <div class="container-fluid p-5">
	 <div class="row">
	 <div class="col-sm-4 p-5">
	 <div class="row">
	 <div class="col-sm-12 cat"style="background:url('images/16.jpg'); background-size:100% 100%;">
	 <a href="#" class="btn btn-light">MEN,S</a>
	 </div>
	 </div>
	 </div>
	 <div class="col-sm-4 p-5">
	  <div class="row">
	  <div class="col-sm-12 cat" style="background:url('images/16.jpg'); background-size:100% 100%;">
	  <a href="#" class="btn btn-light">WOMEN,S</a>
	  </div>
	  </div> 
	  </div>
	 <div class="col-sm-4 p-5">
	  <div class="row">
	   <div class="col-sm-12 cat" style="background:url('images/16.jpg'); background-size:100% 100%;">
	 	 <a href="#" class="btn btn-light">KID'S</a>
	 </div>
	 </div>
	 </div>
	 </div>
	 </div>
	 </div>
     <div class="row main py-5" id="main">
	 <div class="col-sm-12 text-center h2">ABOUT <b style="color:#66a3d1">US
	 <span class="fa fa-users"></b></div>
	 <div class="container text-justify">
	 Employee Management System is a distributed application that enables users to create and store Employee Records. This application is useful to department of the organization which maintains data of employees related to an organization. Employee Management is the modern computer based record management system of employee of any firm. Since it would be very difficult for any firm to maintain the records of employee on the papers and keep their attendance records also, we tried to convert this manpower to computer power. admin side manages all the management like editing site contents, managing employee activities.The Management System helps in management of employee database. It also deals with manipulation of the details of the employees.
	 The System may also be  used as a quick reference.
	 sometimes by accident, sometimes on purpose (injected humour and the like).
	 orem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passag
	 es, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
     Why do we use it?It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that.
	 </div></div>
   	 <a class="nav-link" href="#t"><input type="submit" value="TOP"class="btn btn-primary"></a>
     <div class="row ufooter"  id="l"></div>
     <div class="row bfooter"></div>
	</div>
  </body>
</html>