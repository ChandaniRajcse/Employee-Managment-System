<?php 
session_start();
// echo 'inside login-account';
$host="localhost";
$username="root";
$pass="";
$db="ems";

$conn=mysqli_connect($host,$username,$pass,$db);
if(!$conn){
        die("Database connection error");
}
//login account process 
if(isset($_POST['email']))
{
	$email=$_POST['email'];
	$pass=md5($_POST['password']);	
	$query="select*from users where email='$email'AND password='$pass'";
	// print_r($query);
	$res=mysqli_query($conn,$query);
	$count=mysqli_num_rows($res);
	
	$row=mysqli_fetch_array($res);
print_r($row);
$user_email = $row['email'];
	// die();
// echo $row;
	if($user_email == $email)
	{
		echo "101";
	 $session_id=session_id();
	 $_SESSION['auth']= $session_id;
	 $_SESSION['user_id']=$row['user_id'];
	 $_SESSION['role']=$row['role'];
     if($_SESSION['role']=='admin'){
		
		header('Location:admin/dashboard.php');
	 }
	 elseif($_SESSION['role']=='employee'){
		echo "100";
		 header('Location:employee/dashboard.php');
	 }else{
		echo "ani";
		 $_SESSION['error']="wrong Email or password!";
		header('Location:login.php');	 
	 }
	}
	else{
		echo "ani3";
		$_SESSION['error']="wrong Email or password!";
		header('Location:login.php');
	}
}
?>