<?php  session_start();?>
<html>
  <head>
    <title>login</title>
	 <link href="css/style2.css" rel="stylesheet">
	 <script src="js/jquery-3.5.1.min.js"></script>
	 <!--<link href="css/bootstrap.css" rel="stylesheet"/>-->
	 <style>
	      .a{
			  min-height:700px;
			  background:url(images/6.jpg);
			  background-size:100% 100%;
		  }
	 </style>
	 <script>
	    function formvalidation(){
		    var email=$('#inputEmail').val();
			var password=$('#inputPassword').val();
			var passlength=$('#inputPassword').val().length;
			if(email=='')
			{
				alert("please enter your email");
				return false;
			}
			if(password=='')
			{
				alert("please enter your password");
				return false;
			}
			if(passlength<6)
			{
				alert("please enter your 6 digit password");
				return false;
			}
		}
	 </script>
	</head>
  <body >
  <header>  
  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar">Register</span>
        <span class="icon-bar">Login</span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="index.php">EMS</a>
    </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
	<ul class="nav navbar-nav">
	   <li><a href="registeration.php">Register</a></li>
      <form class="navbar-form navbar-left" role="search">
         </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="login.php">Login</a></li>
      </ul>
    </div>
  </div>
</nav>
</header>
  <div class="container a">
  <div class="col-xs-6 col-xs-push-3 well">
  
  <!----------------login form start from here-------------->
<form class="form-horizontal " method="post" action="login-account.php" onsubmit="return formvalidation();">
  <fieldset>
    <legend><b>Login</b></legend>
	<?php
	if(isset($_SESSION['error']))
	{
		echo $_SESSION['error'];
        unset($_SESSION['error']);   		
	}
	if(isset($_SESSION['success']))
	{
		echo $_SESSION['success'];
		 unset($_SESSION['success']);
	}
	?>
    <div class="form-group">
      <label for="inputEmail" class="col-lg-2 control-label"><b>Email</b></label>
      <div class="col-lg-10">
        <input type="email" style="background-color:white;" class="form-control" name="email"id="inputEmail" placeholder="Email">
      </div>
    </div>
    <div class="form-group">
      <label for="inputPassword" class="col-lg-2 control-label"><b>Password</b></label>
      <div class="col-lg-10">
        <input type="password" style="background-color:white;" class="form-control" name="password"id="inputPassword" placeholder="Password">
      </div>
    </div>
    
    <div class="form-group">
      <div class="col-lg-10 col-lg-offset-2">
         <button type="submit" class="btn btn-info">Login</button>
		 </div>
		 <div class="col-lg-10 col-lg-offset-2">
		 <b>If you have not an account?</b><a href="registeration.php">Register</a>
           
		 
          </div>
    </div>
  </fieldset>
 </form>
 <!----------login form end here--------------->
 </div>
</body>
</html>